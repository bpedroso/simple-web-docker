package com.bpedroso.poc.deploy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CdApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CdApiApplication.class, args);
	}
}
